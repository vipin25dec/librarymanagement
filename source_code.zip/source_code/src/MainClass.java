/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class MainClass 
{
    //change your mysql database connection here
    public String StrUrl="jdbc:mysql://localhost/libdatabase"; //db name
    public String StrUid="libuser";
    public String StrPwd= "LibUser@1"; //password
    
    public static String StrUser;
            

}
